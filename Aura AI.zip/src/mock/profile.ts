import type {
  AssetEntry,
  ProfileIdentity,
  SettingItem,
  SkinDataOverview,
} from "@/types/profile";

export const mockProfileIdentity: ProfileIdentity = {
  nickname: "雨涵",
  aiIdentity: "Skin Explorer",
  skinLabel: "混合偏油",
  joinedAt: "2026-03-11",
  avatarLetter: "雨",
};

export const mockSkinDataOverview: SkinDataOverview = {
  stabilityScore: 82,
  sensitivityScore: 65,
  recordDays: 28,
  aiLearnCount: 36,
  trendRangeLabel: "过去 30 天",
  trends: [
    { id: "redness", label: "泛红", change: "↓ 20%", direction: "down", positive: true },
    { id: "oil", label: "油脂稳定", change: "↑ 15%", direction: "up", positive: true },
    { id: "barrier", label: "屏障状态", change: "逐渐改善", direction: "steady", positive: true },
  ],
};

export const mockAssetEntries: AssetEntry[] = [
  {
    id: "asset_products",
    title: "产品库",
    icon: "products",
    to: "/analysis",
    metrics: [
      { label: "正在使用", value: "12 件" },
      { label: "收藏", value: "24 件" },
    ],
  },
  {
    id: "asset_reports",
    title: "AI 分析记录",
    icon: "reports",
    to: "/analysis",
    metrics: [{ label: "历史报告", value: "18 份" }],
  },
  {
    id: "asset_logs",
    title: "肤感记录",
    icon: "logs",
    to: "/coach",
    metrics: [{ label: "累计", value: "36 次" }],
  },
];

export const mockSettingItems: SettingItem[] = [
  { id: "account", title: "账号设置", description: "昵称、头像与登录方式", icon: "account" },
  { id: "privacy", title: "隐私管理", description: "AI 可使用的数据范围", icon: "privacy" },
  { id: "data", title: "数据管理", description: "导出、同步与清理", icon: "data" },
  { id: "notify", title: "通知设置", description: "护理提醒与风险提示", icon: "bell" },
  { id: "about", title: "关于 BeautyAI", description: "版本 1.0.0", icon: "info" },
];
