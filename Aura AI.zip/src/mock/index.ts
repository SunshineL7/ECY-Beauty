import type {
  AiAdvice,
  AnalysisReport,
  AppNotification,
  CommunityPost,
  DailyLog,
  DailySkinReport,
  FeatureEntry,
  Product,
  SkinProfile,
  UserProfile,
} from "@/types";

export const mockUser: UserProfile = {
  id: "u_001",
  nickname: "Luna",
  joinedAt: "2026-03-11",
  streakDays: 28,
  skinProfileId: "sp_001",
};

export const mockSkinProfile: SkinProfile = {
  id: "sp_001",
  userId: "u_001",
  skinType: "combination",
  concerns: ["泛红", "T区出油", "偶发闭口"],
  allergens: ["酒精", "香精"],
  barrierScore: 68,
  hydrationScore: 74,
  updatedAt: "2026-08-03",
};

export const mockDailySkinReport: DailySkinReport = {
  id: "dsr_001",
  date: "2026-08-03",
  stabilityScore: 82,
  skinTypeLabel: "混合偏油",
  sensitivityScore: 65,
  issues: ["泛红", "T区出油", "偶发闭口"],
  aiAdvice: "今天以舒缓修护为主",
};

export const mockFeatureEntries: FeatureEntry[] = [
  {
    id: "fe_profile",
    title: "肤质画像",
    description: "多维度了解我的肌肤状态",
    icon: "profile",
    to: "/profile",
    highlights: ["混合偏油", "肌肤年龄 22", "中度敏感"],
  },
  {
    id: "fe_products",
    title: "产品库",
    description: "管理我的护肤产品与收藏",
    icon: "products",
    to: "/analysis",
  },
  {
    id: "fe_logs",
    title: "肤感记录",
    description: "追踪每日肌肤变化与AI反馈",
    icon: "logs",
    to: "/coach",
  },
];

export const mockRecentReports: AnalysisReport[] = [
  {
    id: "ar_001",
    productName: "理肤泉修护霜",
    brand: "La Roche-Posay",
    safetyScore: 88,
    matchRate: 92,
    analyzedAt: "今天 10:30",
  },
];

export const mockNotifications: AppNotification[] = [
  {
    id: "n_001",
    title: "今日护理建议已生成",
    body: "屏障指数回升中，建议减少活性成分叠加。",
    createdAt: "今天 08:00",
    read: false,
  },
  {
    id: "n_002",
    title: "分析完成",
    body: "理肤泉B5修护霜 安全评分 92。",
    createdAt: "今天 10:30",
    read: true,
  },
];

export const mockDailyLogs: DailyLog[] = [
  {
    id: "log_003",
    date: "2026-08-03",
    moodScore: 4,
    hydration: 76,
    oiliness: 38,
    irritation: 18,
    note: "早间清洁后无刺痛感",
  },
  {
    id: "log_002",
    date: "2026-08-02",
    moodScore: 3,
    hydration: 70,
    oiliness: 44,
    irritation: 26,
  },
  {
    id: "log_001",
    date: "2026-08-01",
    moodScore: 3,
    hydration: 66,
    oiliness: 47,
    irritation: 33,
  },
];

export const mockProducts: Product[] = [
  {
    id: "p_001",
    brand: "Aeris",
    name: "屏障修护精华",
    category: "精华",
    safetyScore: 92,
    ingredients: [
      {
        id: "i_001",
        name: "神经酰胺 NP",
        aliasEn: "Ceramide NP",
        risk: "safe",
        function: "屏障修护",
        description: "补充细胞间脂质，帮助修复受损屏障。",
      },
      {
        id: "i_002",
        name: "变性乙醇",
        aliasEn: "Alcohol Denat.",
        risk: "caution",
        function: "溶剂",
        description: "高浓度可能加重敏感肌刺激感。",
      },
    ],
  },
];

export const mockAdvice: AiAdvice = {
  id: "a_001",
  date: "2026-08-03",
  title: "今日以「减法护理」为主",
  summary: "屏障指数回升中，建议减少活性成分叠加，专注保湿与防晒。",
  steps: ["温和氨基酸洁面", "神经酰胺精华 2 泵", "轻质保湿霜", "SPF30 物理防晒"],
  confidence: 0.86,
};

export const mockPosts: CommunityPost[] = [
  {
    id: "c_001",
    author: "小满",
    avatarColorToken: "primary",
    content: "换季泛红三周，靠简化流程慢慢稳住了。",
    tags: ["敏感肌", "换季"],
    likes: 128,
    createdAt: "2026-08-02",
  },
  {
    id: "c_002",
    author: "Yiwen",
    avatarColorToken: "ai",
    content: "AI 成分分析帮我避开了一个高浓度酒精的爽肤水。",
    tags: ["成分分析"],
    likes: 76,
    createdAt: "2026-08-01",
  },
];
