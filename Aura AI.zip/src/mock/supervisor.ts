import type {
  AiSkinSummary,
  AiSuggestion,
  SkinRoutine,
  TrendPoint,
} from "@/types/supervisor";

export const mockSkinRoutine: SkinRoutine = {
  id: "sr_001",
  date: "2026-08-03",
  morning: [
    { id: "m1", label: "洁面", product: "氨基酸温和洁面", icon: "cleanse", done: true },
    { id: "m2", label: "精华", product: "屏障修护精华", icon: "serum", done: true },
    { id: "m3", label: "防晒", product: "SPF30 物理防晒", icon: "sunscreen", done: false },
  ],
  night: [
    { id: "n1", label: "卸妆", product: "温和卸妆啫喱", icon: "remove", done: false },
    { id: "n2", label: "修护精华", product: "神经酰胺修护精华", icon: "repair", done: false },
    { id: "n3", label: "面霜", product: "理肤泉 B5 修护霜", icon: "cream", done: false },
    { id: "n4", label: "记录肤感", product: "完成后填写今日肤感", icon: "log", done: false },
  ],
};

export const mockAiSuggestion: AiSuggestion = {
  id: "as_001",
  problem: "近 3 天泛红增加",
  recommendation: "今晚减少刺激产品使用频率，增加修护步骤。",
  reason: "你的肤感记录显示，屏障状态需要恢复。",
  detectedAt: "今天 08:00",
};

export const mockAiSkinSummary: AiSkinSummary = {
  id: "sum_001",
  rangeLabel: "最近 7 天记录",
  summary: "你的肌肤稳定度提升 12%，修护产品适配良好，建议继续保持当前方案。",
  metrics: [
    { label: "稳定度", delta: 12, positive: true },
    { label: "泛红", delta: -20, positive: true },
    { label: "刺痛感", delta: -8, positive: true },
  ],
};

export const mockTrendPoints: TrendPoint[] = [
  { date: "7/28", stability: 64, sensitivity: 58 },
  { date: "7/29", stability: 66, sensitivity: 55 },
  { date: "7/30", stability: 69, sensitivity: 52 },
  { date: "7/31", stability: 72, sensitivity: 50 },
  { date: "8/01", stability: 75, sensitivity: 46 },
  { date: "8/02", stability: 79, sensitivity: 43 },
  { date: "8/03", stability: 82, sensitivity: 40 },
];
