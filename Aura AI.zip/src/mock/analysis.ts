import type {
  AnalysisResultDetail,
  AnalysisStep,
  RecentAnalysisSummary,
} from "@/types/analysis";

export const mockAnalysisSteps: AnalysisStep[] = [
  { id: "s1", label: "产品识别完成", duration: 1000 },
  { id: "s2", label: "成分提取完成", duration: 1000 },
  { id: "s3", label: "风险分析完成", duration: 1100 },
  { id: "s4", label: "肤质匹配完成", duration: 1000 },
  { id: "s5", label: "生成个性化建议", duration: 900 },
];

export const mockRecentAnalysis: RecentAnalysisSummary = {
  id: "ar_001",
  productName: "理肤泉 B5 修护霜",
  brand: "La Roche-Posay",
  safetyScore: 92,
  matchRate: 95,
  analyzedAt: "今天 10:30",
};

export const mockAnalysisResult: AnalysisResultDetail = {
  id: "ar_001",
  brand: "理肤泉",
  brandEn: "La Roche-Posay",
  productName: "理肤泉 B5 修护霜",
  category: "面霜 · 屏障修护",
  analyzedAt: "今天 10:30",
  safetyScore: 92,
  matchRate: 95,
  repairScore: 90,
  skin: {
    type: "混合偏油",
    sensitivity: 65,
    concerns: ["屏障偏弱", "局部泛红"],
  },
  matchReasons: [
    { ingredient: "含泛醇", effect: "帮助修护屏障" },
    { ingredient: "含神经酰胺", effect: "提升保湿能力" },
    { ingredient: "低刺激配方", effect: "适合敏感状态" },
  ],
  ingredients: [
    { name: "泛醇", aliasEn: "Panthenol", type: "benefit", note: "促进屏障修护，缓解泛红" },
    {
      name: "神经酰胺",
      aliasEn: "Ceramide NP",
      type: "benefit",
      note: "补充细胞间脂质，锁住水分",
    },
    {
      name: "积雪草苷",
      aliasEn: "Madecassoside",
      type: "benefit",
      note: "舒缓敏感，抑制炎症反应",
    },
    { name: "香精", aliasEn: "Fragrance", type: "watch", note: "敏感肌建议先做耳后测试" },
  ],
  highlights: [
    { name: "泛醇", aliasEn: "Panthenol", benefit: "促进屏障修护，缓解泛红与刺痛" },
    { name: "神经酰胺", aliasEn: "Ceramide NP", benefit: "补充细胞间脂质，减少经皮水分流失" },
    { name: "积雪草苷", aliasEn: "Madecassoside", benefit: "舒缓敏感、抑制炎症反应" },
  ],
  risks: [
    { name: "香精", level: "caution", reason: "你的敏感画像中含香精不耐受记录，建议观察" },
    { name: "苯氧乙醇", level: "caution", reason: "常规防腐剂，浓度安全，屏障受损期可能有轻微刺感" },
  ],
  aiSuggestions: [
    "建议晚间使用，作为护肤流程的最后一步锁水",
    "搭配你产品库中的舒缓精华，可提升修护效率",
    "泛红期可厚敷 10 分钟当作睡眠面膜",
  ],
  recommendation: {
    time: "晚上使用",
    frequency: "每日一次",
    pairing: "修护面霜",
  },
  summary: "配方温和，修护向成分占比高，与你的「混合偏油 + 屏障偏弱」画像高度契合。",
};
